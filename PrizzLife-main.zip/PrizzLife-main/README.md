<h1 align="center">PrizzLife Admin</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Status-Inactive-red" alt="Status">
  <img src="https://img.shields.io/badge/Version-0.8.1-blue" alt="Version">
  <img src="https://img.shields.io/github/license/devguy100/PrizzLife" alt="License">
</p>

<p align="center">
  <strong>PrizzLife</strong> - A powerful exploit tool for Roblox <a href="https://www.roblox.com/games/155615604/Prison-Life">Prison Life</a> with multi-executor support.
</p>

---

<h2 align="center">⚠️ Important Notice</h2>

<p align="center">
  <strong>This project is no longer maintained.</strong><br>
  No updates, bug fixes, or support will be provided. Use at your own risk.
</p>


---

## 🚀 Supported Executors

```plaintext
LibHydrogen based executors: Delta X 2.0, Hydrogen, MacSploit
LibArceusX based executors: Arceus X Neo, Codex, VegaX, Evon, Trigon
Misc executors: Fluxus, Solara PC, Swift, Other Mobile Executors, etc.
```

---

### Discord:
<div style="text-align: center;">
  <a href="https://discord.gg/yMyYPfmkBc" target="_blank">Join our Discord</a>
</div>

---

## 🔗 Usage

Copy and paste the following script into your Roblox executor to load PrizzLife:

```lua
loadstring(game:HttpGet('https://raw.githubusercontent.com/devguy100/PrizzLife/main/pladmin.lua'))()
```

---

## 📜 License

This project is licensed under the MIT License. See the LICENSE file for more details.

---

<p align="center">
  <strong>Happy exploiting! 🚀</strong>
</p>
